AW RADIO STATION BUILDER Version 0.1
====================================

A standalone local HTML tool that generates ready-to-install station packs for
AWRadioFramework.

Open AW_Radio_Station_Builder.html in Chrome, Edge, Opera GX or any Browser.
No installation, server, account, or internet connection is required.

- Station indices 0-999 are reserved.
- User station indices are restricted to 1000-9999.
- A new index is randomized whenever the HTML builder opens.
- A Randomize button can generate another index at any time.
- Embedded Artist and Title metadata is read when available from:
  - MP3 ID3v2 and ID3v1 tags
  - FLAC Vorbis comments
  - OGG Vorbis comments and Opus comments
  - WAV INFO and embedded ID3 metadata
- The displayed radio title is generated as Artist - Song Title.
- If metadata is unavailable, the source filename remains the fallback.

IMPORTANT
---------
Randomizing an index reduces collision risk but cannot guarantee that another
station pack does not use the same number. Authors should still publish the
chosen station index on their mod page.

Only distribute audio and artwork you have permission to distribute.
