AW Radio Station Builder v0.3.0
=================================

Open AW_Radio_Station_Builder_v0.3.0.html in a modern browser.
No installation or internet connection is required.

RadioExt station import
-----------------------
The Builder can import one existing RadioExt station folder.

Select the folder that contains:
- metadata.json
- the station's local audio files

The importer automatically reads and fills:
- display/station name
- frequency, normalized to Radioport's one-decimal format
- internal AWRF station name derived from the station name
- RadioExt volume as the starting AWRF gain when it fits the valid range
- existing game UIIcon record
- custom inkAtlasPath and inkAtlasPart when useCustom is true
- all local WAV, OGG, MP3, and FLAC files in the station folder

A new AWRF station index is randomized during import.

Custom icon archives are optional. When RadioExt metadata declares a custom atlas, the generated AWRF station references that atlas resource directly. If the original archive is already installed in Cyberpunk 2077\archive\pc\mod, no archive needs to be selected in the Builder. The existing archive picker can still be used when a fully standalone converted package is desired.

RadioExt limitations during conversion
--------------------------------------
- Web streams are detected but not converted to local Audioware tracks.
- MP2, WAX, and WMA files are reported but not imported because AWRF currently packages WAV, OGG, MP3, and FLAC.
- A non-empty RadioExt order list is reported because AWRF currently shuffles station tracks.
- If multiple metadata.json files are found, the import is stopped and the user is asked to select one individual station folder.

Frequency conversion
--------------------
AWRF Radioport names support one decimal digit. RadioExt frequencies are rounded to the nearest tenth during import.

Example:
104.07 DNB RADIO -> 104.1 DNB RADIO

The editable Builder fields remain available after import.

MP3 compatibility cleanup
-------------------------
Embedded MP3 cover artwork is automatically removed only from the packaged copies. Text metadata and MPEG audio bytes are preserved and the user's original files are never modified.
