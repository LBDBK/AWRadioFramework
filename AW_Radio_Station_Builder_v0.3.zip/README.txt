AW Radio Station Builder v1.3
=================================

Open AW_Radio_Station_Builder.html in a modern browser.
No installation or internet connection is required.

Internal station name
---------------------
Normal/manual station creation automatically derives Internal station name from Station name.

Example:
Station name: NIGHT CITY DNB
Internal station name: NIGHT_CITY_DNB

The generated value stays editable. Once the user manually edits Internal station name, later Station name changes do not overwrite that custom value.

There is no separate Generate button. The normal workflow is intentionally automatic to keep the form simple.

RadioExt import continues to derive the internal name automatically.

File picker readability
-----------------------
The two native file picker buttons now use the Builder's dark button styling:
- Existing RadioExt station folder
- Add tracks

This prevents the browser's light default file-picker button from producing low-contrast text on the dark Builder theme.

Preserved functionality
-----------------------
- RadioExt station-folder importer.
- One-decimal Radioport frequency controls.
- Randomized station index.
- Optional custom icon archive packaging.
- MP3 compatibility normalization.
- Embedded MP3 artwork removal on packaged copies.
- Original MPEG audio-byte preservation.
