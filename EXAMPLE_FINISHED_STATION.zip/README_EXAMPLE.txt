Completed Example: 98.9 NIGHT CITY DNB
=======================================

This example demonstrates matching values across all three files.

Station record:
  RadioStation.NightCityDNB

Station index:
  420

Visible name:
  98.9 NIGHT CITY DNB

Track 1 audio ID:
  nightcitydnb_neon_velocity

The same ID appears in:
  audios.yml
  NightCityDNB.reds

No real audio files are included.
The file names and durations are examples only.
