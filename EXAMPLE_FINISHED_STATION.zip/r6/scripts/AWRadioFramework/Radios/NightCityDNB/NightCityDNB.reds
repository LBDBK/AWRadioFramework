module NightCityDNB

import AWRadioFramework.*
import Codeware.*

public abstract class NightCityDNBFactory {
  public static func Build() -> ref<AWRadioStationDefinition> {
    let station = AWRadioStationDefinition.Create(
      t"RadioStation.NightCityDNB",
      420,
      n"98.9 NIGHT CITY DNB",
      1.0
    );

    station.AddTrack(
      AWRadioTrackDefinition.Create(
        n"nightcitydnb_neon_velocity",
        "Nova Static - Neon Velocity",
        213.4
      )
    );

    station.AddTrack(
      AWRadioTrackDefinition.Create(
        n"nightcitydnb_afterlife_run",
        "Chrome Pulse - Afterlife Run",
        245.0
      )
    );

    station.AddTrack(
      AWRadioTrackDefinition.Create(
        n"nightcitydnb_city_at_3am",
        "Ghost Circuit - City at 3AM",
        198.7
      )
    );

    return station;
  }
}

public class NightCityDNBProvider extends ScriptableService {
  private cb func OnInitialize() -> Void {
    this.Register();
  }

  private cb func OnReload() -> Void {
    this.Register();
  }

  private func Register() -> Void {
    let framework = AWRadioService.Get();

    if IsDefined(framework) {
      framework.RegisterStation(
        NightCityDNBFactory.Build()
      );
    }
  }
}
